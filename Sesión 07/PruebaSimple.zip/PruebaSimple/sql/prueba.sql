drop table prueba;

create table prueba(
 id integer primary key,
 nombre varchar(20)
 );
 
insert into prueba values (1, 'uno');
insert into prueba values (2, 'dos');
insert into prueba values (3, 'tres');

commit;

exit;