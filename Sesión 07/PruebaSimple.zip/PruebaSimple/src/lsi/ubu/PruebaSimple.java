package lsi.ubu;


import java.sql.Connection;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import lsi.ubu.util.ExecuteScript;



public class PruebaSimple {
	
	private static Logger l = LoggerFactory.getLogger(PruebaSimple.class);
	

	public static void main(String[] args) {
		PoolDeConexiones pool = null;
		Connection conn = null;
				
		try {
				pool = PoolDeConexiones.getInstance();
				conn = pool.getConnection();
				
				l.info("Conexion creada.");				
				l.info("La conexion es valida: "+conn.isValid(0));
				
				ExecuteScript.run("sql/prueba.sql");
				
		} catch ( SQLException e) {
			l.error(e.getMessage());
		} finally {
			
			try {
				conn.close();
				l.info("Conexion cerrada.");
				l.info("La conexion es valida: "+conn.isValid(0));
			} catch ( SQLException e ) {
				l.error("Error al cierre de la conexion.");
				l.error(e.getMessage());
			}
		}


	}

}
